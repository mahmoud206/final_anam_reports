package com.example.vetra_anaam_report

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
