class Database {
  final int id;
  final String name;
  final String symbol;

  Database({
    required this.id,
    required this.name,
    required this.symbol,
  });
}